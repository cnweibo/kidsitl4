<?php

return array(

	'actions' => 'A&ccedil;&otilde;es'

);
