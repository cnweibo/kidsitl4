<?php

return array(

	'title'      => 'Titulo do Blog',
	'comments'   => '# de Comentários',
	'created_at' => 'Criado em',
	'post_id'    => 'Id do Post',

);
