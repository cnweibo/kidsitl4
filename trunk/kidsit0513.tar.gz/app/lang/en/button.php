<?php

return array(

	'edit'   => 'Edit',
	'delete' => 'Delete'
);
