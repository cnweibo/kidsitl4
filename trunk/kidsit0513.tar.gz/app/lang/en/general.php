<?php

return array(

	'yes' => 'Yes',
	'no'  => 'No',
    'must_login' => 'Must be logged in.'

);
