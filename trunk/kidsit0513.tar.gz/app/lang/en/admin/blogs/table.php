<?php

return array(

	'title'      => 'Blog Title',
	'comments'   => '# of Comments',
	'created_at' => 'Created at',
	'post_id' => 'Post Id',

);
