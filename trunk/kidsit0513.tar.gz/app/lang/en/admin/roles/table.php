<?php

return array(

	'name'       => 'Name',
	'users'      => '# of Users',
	'created_at' => 'Created at',

);
