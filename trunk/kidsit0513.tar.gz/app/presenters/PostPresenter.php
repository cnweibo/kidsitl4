<?php

use Robbo\Presenter\Presenter;

class PostPresenter extends Presenter
{

}