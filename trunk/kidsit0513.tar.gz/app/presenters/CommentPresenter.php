<?php

use Robbo\Presenter\Presenter;

class CommentPresenter extends Presenter
{

}